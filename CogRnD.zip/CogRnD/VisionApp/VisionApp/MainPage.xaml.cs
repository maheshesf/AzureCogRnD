﻿using Plugin.Media;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisionHelperForAPP;
using Xamarin.Forms;

namespace VisionApp
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(true)]
    public partial class MainPage : ContentPage
    {
        static string filePath = string.Empty;
        public MainPage()
        {
            InitializeComponent();

        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            await CrossMedia.Current.Initialize();

            if (!CrossMedia.Current.IsTakePhotoSupported && !CrossMedia.Current.IsPickPhotoSupported)
            {
                await DisplayAlert("Message", "Photo Picture and pic not supported", "ok");
                return;
            }
            else
            {

                //new Random().Next(1,1000).ToString()





                var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
                {
                    //Directory = "Images",
                    //Name = "/storage/emulated/0/DCIM/Camera/test.jpg",
                    //SaveToAlbum = true

                    // Directory = "Sample",
                    //Name = "test.jpg",
                    SaveToAlbum = true
                });

                if (file == null)
                {
                    return;
                }
                else
                {
                    MyImage.IsVisible = true;
                    filePath = file.Path;
                    //await DisplayAlert("File path", file.Path, "Ok");

                    MyImage.Source = ImageSource.FromStream(() =>
                    {
                        var stream = file.GetStream();
                        return stream;
                    });

                    Trans.IsVisible = true;
                }
            }
        }

        private async void Button_Translate(object sender, EventArgs e)
        {
            var textFound = await Class1.BatchReadFileLocal1(filePath);
            await DisplayAlert("Extracted text from an image ", textFound, "Click here to Translate !");
            var trans = await Class1.TranslateTextToLocalLanguage(textFound);
            await DisplayAlert("Translated text ", trans, "Click here to start again !");
            Trans.IsVisible = false;
            MyImage.IsVisible = false;
        }
    }
}
