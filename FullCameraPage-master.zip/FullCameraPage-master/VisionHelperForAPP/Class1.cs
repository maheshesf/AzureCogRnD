﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace VisionHelperForAPP
{
    public class Class1
    {

        static string subscriptionKey = "cdedcee5e93f43dfa363f6f5e03bd292";
        static string endpoint = "https://demovisioncarrier.cognitiveservices.azure.com/";

        public static ComputerVisionClient Authenticate(string endpoint, string key)
        {
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        public static async Task<string> BatchReadFileLocal1(string localImage)
        {
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);

            Console.WriteLine("----------------------------------------------------------");
            Console.WriteLine("BATCH READ FILE - LOCAL IMAGE");
            Console.WriteLine();

            // Helps calucalte starting index to retrieve operation ID
            const int numberOfCharsInOperationId = 36;

            Console.WriteLine($"Extracting text from local image {Path.GetFileName(localImage)}...");
            Console.WriteLine();
            StringBuilder builder = new StringBuilder();

            using (Stream imageStream = File.OpenRead(localImage))
            {
                // Read the text from the local image
                BatchReadFileInStreamHeaders localFileTextHeaders =   client.BatchReadFileInStreamAsync(imageStream).Result;
                // Get the operation location (operation ID)
                string operationLocation = localFileTextHeaders.OperationLocation;

                // Retrieve the URI where the recognized text will be stored from the Operation-Location header.
                string operationId = operationLocation.Substring(operationLocation.Length - numberOfCharsInOperationId);

                // Extract text, wait for it to complete.
                int i = 0;
                int maxRetries = 10;
                ReadOperationResult results;
                do
                {
                    results =   client.GetReadOperationResultAsync(operationId).Result;
                    Console.WriteLine("Server status: {0}, waiting {1} seconds...", results.Status, i);
                    //await Task.Delay(1000);
                    if (i == 9)
                    {
                        Console.WriteLine("Server timed out.");
                    }
                }
                while ((results.Status == TextOperationStatusCodes.Running ||
                    results.Status == TextOperationStatusCodes.NotStarted) && i++ < maxRetries);

                // Display the found text.
                Console.WriteLine();

                var textRecognitionLocalFileResults = results.RecognitionResults;
                foreach (TextRecognitionResult recResult in textRecognitionLocalFileResults)
                {
                    foreach (Line line in recResult.Lines)
                    {
                        Console.WriteLine(line.Text);
                        builder.AppendLine(line.Text);
                    }
                }
                Console.WriteLine();
            }

            return builder.ToString();
        }

        static public async Task<string> DetectTextRequest(string subscriptionKey, string endpoint, string inputText)
        {
            System.Object[] body = new System.Object[] { new { Text = inputText } };
            var requestBody = JsonConvert.SerializeObject(body);

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                // In the next few sections you'll add code to construct the request.
                // Build the request.
                request.Method = HttpMethod.Post;
                // Construct the URI and add headers.
                request.RequestUri = new Uri(endpoint);
                request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

                // Send the request and get response.
                HttpResponseMessage response = await client.SendAsync(request).ConfigureAwait(false);
                // Read response as a string.
                string result = await response.Content.ReadAsStringAsync();
                // Deserialize the response using the classes created earlier.

                TranslationResult[] deserializedOutput = JsonConvert.DeserializeObject<TranslationResult[]>(result);


                StringBuilder str = new StringBuilder();


                str.AppendLine("Translated to Hindi :");
                str.AppendLine(deserializedOutput[0].Translations[0].Text);

                str.AppendLine("Translated to Telugu :");
                str.AppendLine(deserializedOutput[0].Translations[1].Text);

                str.AppendLine("Translated to Bangla :");
                str.AppendLine(deserializedOutput[0].Translations[2].Text);

                return str.ToString();
            }
        }

        public static async Task<string> TranslateTextToLocalLanguage(string text)
        {
            return DetectTextRequest("33371eb167334a3ebf95e863e4ca73f5", "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=hi&to=te&to=bn", text).Result;
            //return DetectTextRequest("33371eb167334a3ebf95e863e4ca73f5", "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=hi", text).Result;

        }
        public static async Task<string> GetTextFromImage(string path)
        {
            try
            {

                ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);

                return await BatchReadFileLocal1(path);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Console.WriteLine("----------------------------------------------------------");
                Console.WriteLine();
                Console.WriteLine("Computer Vision quickstart is complete.");
                Console.WriteLine();
                Console.WriteLine("Press enter to exit...");
                Console.WriteLine();
            }
        }
    }

    public class TranslationResult
    {
        public DetectedLanguage DetectedLanguage { get; set; }
        public TextResult SourceText { get; set; }
        public Translation[] Translations { get; set; }
    }

    public class DetectedLanguage
    {
        public string Language { get; set; }
        public float Score { get; set; }
    }

    public class TextResult
    {
        public string Text { get; set; }
        public string Script { get; set; }
    }

    public class Translation
    {
        public string Text { get; set; }
        public TextResult Transliteration { get; set; }
        public string To { get; set; }
        public Alignment Alignment { get; set; }
        public SentenceLength SentLen { get; set; }
    }

    public class TransliterationResult
    {
        public string Text { get; set; }
        public string Script { get; set; }
    }

    public class Alignment
    {
        public string Proj { get; set; }
    }

    public class SentenceLength
    {
        public int[] SrcSentLen { get; set; }
        public int[] TransSentLen { get; set; }
    }
}